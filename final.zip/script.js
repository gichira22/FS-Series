document.addEventListener("DOMContentLoaded", function () {
  const characterList = document.getElementById("characterList");
  const searchInput = document.getElementById("searchInput");
  const favoritesButton = document.getElementById("favoritesButton");
  const commentInput = document.getElementById("commentInput");
  const commentSubmitButton = document.getElementById("commentSubmitButton");

  function navigateTo(page) {
    console.log("Navigating to:", page);
  }
  // Fetch character data from API
  fetch("https://finalspaceapi.com/api/v0/character/")
    .then((response) => response.json())
    .then((data) => {
      displayCharacters(data);

      // Add event listener for search input

      // searchInput.addEventListener("input", function () {
      //   const searchString = searchInput.value.toLowerCase();
      //   const filteredCharacters = data.filter((character) =>
      //     character.name.toLowerCase().includes(searchString)
      //   );
      //   displayCharacters(filteredCharacters);
      // });
      function searchInput() {
        const searchString = searchInput.value.toLowerCase();
        fetch("https://finalspaceapi.com/api/v0/character/")
          .then((response) => response.json())
          .then((data) => {
            displayCharacters(data);
            const filteredCharacters = data.filter((character) =>
              character.name.toLowerCase().includes(searchString)
            );
            displayCharacters(filteredCharacters);
          })
          .catch((error) => console.error("Error fetching products:", error));
      }
      // Add event listener for favorites button
      favoritesButton.addEventListener("click", function () {
        const favorites = JSON.parse(localStorage.getItem("favorites")) || [];
        displayCharacters(favorites);
        data.favorites++;
        favouritesCountElement.textContent = `${data.favorites} favorites`;
      });
    })
    .catch((error) => console.error("Error fetching character data:", error));

  // Add event listener for comment submission
  commentSubmitButton.addEventListener("click", function () {
    const comment = commentInput.value.trim();
    if (comment !== "") {
      alert("Comment submitted successfully!");
      commentInput.value = "";
    }
  });

  function displayCharacters(characters) {
    characterList.innerHTML = "";
    characters.forEach((character) => {
      const characterCard = document.createElement("div");
      characterCard.classList.add("characterCard");

      const characterImage = document.createElement("img");
      characterImage.src = character.img_url;
      characterImage.alt = character.name;

      const characterDetails = document.createElement("div");
      characterDetails.classList.add("characterDetails");

      const characterName = document.createElement("h2");
      characterName.textContent = character.name;

      const characterStatus = document.createElement("h4");
      characterStatus.textContent = `Status: ${character.status}`;

      const characterSpecies = document.createElement("p");
      characterSpecies.textContent = `Species: ${character.species}`;

      const characterGender = document.createElement("h4");
      characterSpecies.textContent = `Gender: ${character.gender}`;

      const characterHair = document.createElement("h4");
      characterHair.textContent = `Hair: ${character.hair}`;

      const characterAlias = document.createElement("p");
      characterAlias.textContent = `Alias: ${character.alias}`;

      const favoriteButton = document.createElement("button");
      favoriteButton.textContent = "Favorite";
      favoriteButton.addEventListener("click", function () {
        addToFavorites(character);
      });

      characterDetails.appendChild(characterName);
      characterDetails.appendChild(characterStatus);
      characterDetails.appendChild(characterSpecies);
      characterDetails.appendChild(characterGender);
      characterDetails.appendChild(characterHair);
      characterDetails.appendChild(characterAlias);
      characterDetails.appendChild(favoriteButton);
      characterCard.appendChild(characterImage);
      characterCard.appendChild(characterDetails);
      characterList.appendChild(characterCard);
    });
  }

  function addToFavorites(character) {
    const favorites = JSON.parse(localStorage.getItem("favorites")) || [];
    favorites.push(character);
    localStorage.setItem("favorites", JSON.stringify(favorites));
    alert(`${character.name} added to favorites!`);
  }
});
